package tutorial;

public class File extends Node {
    public File(Node node, String filename) {
        super(node, filename);
    }

    @Override
    public File copy(String newName) throws CloneNotSupportedException {
        File clone = (File) this.clone();
        clone.name = newName;
        return clone;
    }

    @Override
    public String toString() {
        return name;
    }
}
