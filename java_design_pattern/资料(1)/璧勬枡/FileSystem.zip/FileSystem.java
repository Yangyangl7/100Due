package tutorial;

import java.io.FileNotFoundException;

public class FileSystem {
    private Folder root = new Folder(null, "");

    @SuppressWarnings("UnnecessaryLocalVariable")
    private String[] getPathComponents(String name) {
        String[] components = name.split("/");
        // Additional checks can be performed for components if needed.
        return components;
    }

    /**
     * Makes new file and return if file has been created
     *
     * @param filename name of the file
     * @return true, if file has been created
     * @throws FileNotFoundException Subpath cannot be empty
     */
    @SuppressWarnings("UnusedReturnValue")
    public boolean mkFile(String filename) throws FileNotFoundException {
        String[] components = getPathComponents(filename);
        // if first path contains filename, add to root.
        if (components.length == 1 && components[0].length() > 0) {
            File file = root.createFile(filename);
            return file != null;
        } else if (components.length == 1) {
            throw new FileNotFoundException("Empty filename");
        }

        // Otherwise, cycle through file path
        Folder current = root;
        for (int i = 0; i < components.length - 1; i++) {
            if (components[i].length() == 0)
                throw new FileNotFoundException("Invalid file path");
            current = (Folder) current.getSubNode(components[i]);
            if (current == null)
                throw new FileNotFoundException("Invalid folder location");
        }
        current.createFile(components[components.length - 1]);
        return true;
    }

    /**
     * Makes folder recursively
     *
     * @param path path to folder location
     */
    public void mkFolder(String path) {
        String[] components = getPathComponents(path);
        if (checkIfRoot(components)) {
            // root folder does not need to be created
            return;
        }
        Folder prev = root, current = null;
        for (String component : components) {
            current = (Folder) prev.getSubNode(component);
            if (current == null) {
                current = prev.createFolder(component);
            }
            prev = current;
        }
    }

    // checks if root folder is specified
    private boolean checkIfRoot(String[] paths) {
        return paths.length == 1 && paths[0].length() == 0;
    }

    private Node getSubNode(String name) throws FileNotFoundException {
        String[] structure = getPathComponents(name);
        if (checkIfRoot(structure))
            return root;

        Folder current = root, next = null;
        for (String s : structure) {
            next = (Folder) current.getSubNode(s);

            if (next == null)
                throw new FileNotFoundException("Invalid folder location");
            current = next;
        }
        return next;
    }

    public void copyFolder(String oldName, String newName) throws
            FileNotFoundException, NoSuchMethodException, CloneNotSupportedException {
        Node node = this.getSubNode(oldName);
        Folder clone = (Folder) node.copy(newName);
        ((Folder) node.parent).getContent().add(clone);
    }

    public void copyFile(String oldName, String newName) throws
            FileNotFoundException, NoSuchMethodException, CloneNotSupportedException {
        String[] components = this.getPathComponents(oldName);
        String filename = components[components.length - 1];
        StringBuilder path = new StringBuilder();
        for (int i = 0; i < components.length - 1; i++) {
            path.append(components[i]).append("/");
        }

        Folder node = (Folder) this.getSubNode(path.toString());
        String[] _tmp = this.getPathComponents(newName);
        File file = (File) node.getSubNode(filename).copy(_tmp[_tmp.length - 1]);
        node.getContent().add(file);
    }

    public void printContent(String folder) throws FileNotFoundException, NoSuchMethodException {
        System.out.println("Showing content for folder: " + folder);
        Node node = this.getSubNode(folder);
        System.out.println(node.toString());
        System.out.println();
    }
}