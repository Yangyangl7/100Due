package tutorial;

public abstract class Node implements Cloneable {
    protected String name;
    protected Node parent;

    public Node(Node parent, String name) {
        this.parent = parent;
        this.name = name;
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public abstract Node copy(String newName) throws CloneNotSupportedException;
}
