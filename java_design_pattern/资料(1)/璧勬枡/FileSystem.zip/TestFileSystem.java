package tutorial;

class TestFileSystem {
    static FileSystem fs;

    public static void main(String[] args) {
//        testDeepFileFolders();
        testCopyFolder();
//        testCopyFile();
    }

    private static void testCopyFolder() {
        fs = new FileSystem();
        try {
            fs.mkFolder("A");
            fs.mkFile("A/file1.txt");
            fs.copyFolder("A", "B");

            fs.printContent("A");
            fs.printContent("B");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void testDeepFileFolders() {
        fs = new FileSystem();
        try {
            fs.mkFile("file1.txt");

            fs.mkFolder("A");
            fs.mkFile("A/file2.txt");
            fs.printContent("A");

            fs.mkFolder("A/B/C/D/E");
            fs.mkFile("A/B/C/D/E/file3.txt");
            fs.printContent("");
            fs.printContent("A/B/C/D/E");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void testCopyFile() {
        fs = new FileSystem();
        try {
            fs.mkFolder("A");
            fs.mkFile("A/fileA.txt");
            fs.copyFile("A/fileA.txt", "A/fileB.txt");

            fs.printContent("A");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

