package tutorial;

import java.util.ArrayList;
import java.util.List;

public class Folder extends Node {
    private List<Node> filesAndFolders = new ArrayList<Node>();

    public Folder(Node parent, String name) {
        super(parent, name);
    }

    public List<Node> getContent() {
        return filesAndFolders;
    }

    public Folder createFolder(String name) {
        Node node = this.getSubNode(name);
        if (!(node instanceof Folder)) {
            Folder folder = new Folder(this, name);
            filesAndFolders.add(folder);
        }
        return (Folder) this.getSubNode(name);
    }

    public File createFile(String filename) {
        File file = new File(this, filename);
        filesAndFolders.add(file);
        return (File) this.getSubNode(filename);
    }

    public Node getSubNode(String name) {
        for (Node item : filesAndFolders)
            if (item.name.equalsIgnoreCase(name))
                return item;
        return null;
    }

    private void addAll(List<Node> clones) {
        this.filesAndFolders = clones;
    }

    @Override
    public Folder copy(String newName) throws CloneNotSupportedException {
        List<Node> clones = new ArrayList<Node>(filesAndFolders.size());
        for (Node item : filesAndFolders) {
            if (item instanceof File)
                clones.add((File) item.clone());
            else if (item instanceof Folder)
                clones.add((Folder) item.clone());
        }

        Folder newFolder = new Folder(this, newName);
        newFolder.addAll(clones);

        return newFolder;
    }

    public String toString() {
        StringBuilder output = new StringBuilder(this.name + "/");
        for (Node item : filesAndFolders) {
            output.append("\n\t").append(item.name);
            if (item instanceof Folder)
                output.append("/");
        }
        return output.toString();
    }
}
